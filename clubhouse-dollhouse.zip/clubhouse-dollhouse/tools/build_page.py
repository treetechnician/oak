"""
build_page.py - regenerates index.html from the model.

    python3 tools/house_model.py      # cut list, checks, drawings, renders
    python3 tools/build_page.py       # stitches everything into index.html

The page is fully self-contained (images embedded) so it works from GitHub
Pages, from a cloned repo, or as a single downloaded file.
"""
import base64, csv, html, os, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import house_model as M

IN = 25.4

def b64img(name):
    with open(os.path.join(ROOT, "img", name), "rb") as fh:
        return "data:image/png;base64," + base64.b64encode(fh.read()).decode()

def svg(name):
    s = open(os.path.join(ROOT, "img", name)).read()
    return s.replace("<svg ", '<svg class="dwg" ', 1)

def esc(s):
    return html.escape(str(s))

# ------------------------------------------------------------ run the model
proc = subprocess.run([sys.executable, os.path.join(HERE, "house_model.py"), "--no-render"],
                      capture_output=True, text=True, cwd=ROOT)
check_txt = proc.stdout.split("INTERFERENCE CHECK")[1]
check_txt = "INTERFERENCE CHECK" + check_txt
model_ok = proc.returncode == 0

parts = M.build_parts()
m_tot, cg, h_tot, f_back, f_fwd, f_side = M.stability(parts)

# ---------------------------------------------------------------- cut list
rows = list(csv.DictReader(open(os.path.join(ROOT, "docs", "cutlist.csv"))))
cut_html = []
for i, r in enumerate(rows, 1):
    ph = "" if r["phase"] == "1" else ' <span class="tag">phase 2</span>'
    cut_html.append(
        f"<tr><td class=num>{i}</td><td>{esc(r['part'])}{ph}</td><td>{esc(r['material'])}</td>"
        f"<td class=num>{float(r['length_in']):.3f}<small>{esc(r['length_frac'])}</small></td>"
        f"<td class=num>{float(r['width_in']):.3f}<small>{esc(r['width_frac'])}</small></td>"
        f"<td class=num>{esc(r['qty'])}</td><td class=note>{esc(r['notes'])}</td></tr>")

# ------------------------------------------------------- printed parts table
car_x = M.CAR * IN + 2 * ((M.SHAFT - M.CAR) / 2 + 0.15) * IN
printed = [
    # name, file, part=, size (mm, as printed), phase, notes
    ("Elevator car", "elevator_car.scad", "-", (car_x, M.CAR_H * IN + 10, M.CAR * IN), 2,
     "Open face down. Tabs may want supports if they droop."),
    ("Winch housing", "elevator_winch.scad", "housing", (98.5, 94.5, 59.5), 2,
     "Open top up. 4 walls; it's the bearing for the axle."),
    ("Winch lid", "elevator_winch.scad", "lid", (94.5, 94.5, 4.0), 2, "Flat."),
    ("Winch drum", "elevator_winch.scad", "drum", (40.6, 40.6, 61.0), 2,
     "Stands on its flange. Drill bore to 1/4\" after printing."),
    ("Crank", "elevator_winch.scad", "crank", (66.0, 22.0, 36.9), 2,
     "Hub down. 100% infill for the arm is cheap insurance."),
    ("Table", "furniture.scad", "table", (76.0, 50.0, 38.0), 2, "Upside-down prints cleanest."),
    ("Chair (print 2-4)", "furniture.scad", "chair", (38.0, 38.0, 58.0), 2, "Solid sides, no thin legs."),
    ("Bed", "furniture.scad", "bed", (102.0, 58.0, 50.0), 2, ""),
    ("Slide", "furniture.scad", "slide", (150.0, 90.0, 50.0), 2, "Printed on its side, profile down."),
    ("Nameplate", "nameplate.scad", "-", (152.4, 38.1, 5.6), 2, "Filament swap at 4 mm for 2-colour."),
]
SMALL = 1.25 * IN        # small-parts cylinder diameter
BED = (220, 220, 250)    # Ender-3 V3 SE / KE / V3 build volume, mm
pp_html = []
for name, f, part, dims, ph, note in printed:
    s = sorted(dims)
    small_ok = s[1] > SMALL
    bed_ok = sorted(dims)[2] <= 220 and all(d <= 250 for d in dims)
    pp_html.append(
        f"<tr><td>{esc(name)}</td><td><code>{esc(f)}</code></td><td><code>{esc(part)}</code></td>"
        f"<td class=num>{dims[0]:.0f} × {dims[1]:.0f} × {dims[2]:.0f}</td>"
        f"<td class=ok>{'✓ ' + format(s[1], '.0f') + ' mm' if small_ok else '✗ TOO SMALL'}</td>"
        f"<td class=ok>{'✓' if bed_ok else '✗'}</td><td class=note>{esc(note)}</td></tr>")
    assert small_ok and bed_ok, name

# -------------------------------------------------------------- template
page = open(os.path.join(HERE, "page_template.html")).read()
subs = {
    "IMG_BACK": b64img("iso_back.png"),
    "IMG_FRONT": b64img("iso_front.png"),
    "IMG_PHASE1": b64img("iso_back_phase1.png"),
    "SVG_SHEET": svg("sheet_layout.svg"),
    "SVG_FACADE": svg("facade.svg"),
    "SVG_SIDE": svg("side_wall.svg"),
    "CUT_ROWS": "\n".join(cut_html),
    "PRINT_ROWS": "\n".join(pp_html),
    "CHECK_TXT": esc(check_txt.strip()),
    "MODEL_STATUS": "all checks pass" if model_ok else "CHECKS FAILING - see below",
    "T": f"{M.T:.3f}",
    "PITCH": f"{M.PITCH_DEG:.1f}",
    "HEIGHT": f"{h_tot + M.T:.1f}",
    "WEIGHT": f"{m_tot:.0f}",
    "F_BACK": f"{f_back:.1f}",
    "F_FWD": f"{f_fwd:.1f}",
    "F_SIDE": f"{f_side:.1f}",
    "BASE_W": M.frac(M.BASE_X1 - M.BASE_X0),
    "BASE_D": M.frac(M.BASE_Y1 - M.BASE_Y0),
    "Z_MID": f"{M.Z_MID:g}",
    "ROOF_LEN": f"{(M.W/2)/__import__('math').cos(M.THETA):.3f}",
}
for k, v in subs.items():
    page = page.replace("{{" + k + "}}", v)
assert "{{" not in page, page[page.index("{{"):page.index("{{") + 40]
open(os.path.join(ROOT, "index.html"), "w").write(page)
print(f"index.html written ({len(page)/1024:.0f} kB), model: {subs['MODEL_STATUS']}")
