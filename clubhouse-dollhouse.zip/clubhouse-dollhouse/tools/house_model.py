"""
house_model.py - single source of truth for the plywood clubhouse dollhouse.

Units: inches. Coordinate system:
  x = across the width (left side wall outer face at x=0)
  y = depth (front facade outer face at y=0, open back at y=10)
  z = up (top of base = 0)

Running this file:
  * prints the cut list and every geometry / safety check
  * writes docs/cutlist.csv
  * renders img/iso_front.png, img/iso_back.png (z-buffer renderer, numpy only)
  * writes img/sheet_layout.svg, img/facade.svg, img/side_wall.svg

Only numpy + matplotlib are required.  Change T to your measured plywood
thickness and re-run; everything (cut list, drawings, checks) follows.
"""
from __future__ import annotations
import csv, math, os, sys
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)

# ---------------------------------------------------------------- parameters
T        = 0.472    # plywood thickness (12 mm Baltic birch "1/2 in") - MEASURE YOURS
W        = 24.0     # carcass outer width
D        = 10.0     # carcass outer depth (facade front face to open back)
ROOM_H   = 9.0      # clear height of each storey
DADO     = 0.25     # dado depth in side walls for the middle floor
RISE     = 8.0      # roof rise above attic floor top (ridge at W/2)
FRONT_OH = 1.0      # roof overhang in front of the facade
SHAFT    = 3.25     # elevator shaft clear width (x) and depth (y)
CAR      = 3.0      # elevator car outer width & depth
CAR_H    = 4.0      # elevator car outer height
GROOVE_W, GROOVE_D = 0.25, 0.1875   # guide groove for car tabs
BASE_X0, BASE_X1 = -0.75, 28.5
BASE_Y0 = -1.5      # front doorstep
BASE_Y1 = 12.0      # 2" play porch behind the open back (also helps stability)
KERF = 0.125
SHEET = (60.0, 60.0)

SLOPE = RISE / (W / 2)                    # 8/12
THETA = math.atan(SLOPE)                  # roof pitch, rad
PITCH_DEG = math.degrees(THETA)

Z_MID   = ROOM_H                          # underside of middle floor
Z_SIDE  = 2 * ROOM_H + T                  # top of side walls
Z_ATTIC = Z_SIDE + T                      # top of attic floor = eave line
Z_RIDGE = Z_ATTIC + RISE                  # roof underside at ridge
X_DIV   = W / 2 - T / 2                   # divider left face
SH_Y0   = D - SHAFT                       # shaft clear space y-start
SH_X1   = W + SHAFT                       # shaft clear space x-end
CLEAT_W = 1.0

def roof_z(x):
    """roof underside height at x (left half), mirrored for right half."""
    x = min(x, W - x)
    return Z_ATTIC + x * SLOPE

# ------------------------------------------------------------------- parts
class Part:
    """A flat polygon (with optional holes) extruded between d0 and d1.
    plane 'xz' -> polygon (x,z), extruded along y
    plane 'yz' -> polygon (y,z), extruded along x
    plane 'xy' -> polygon (x,y), extruded along z
    """
    def __init__(self, name, plane, poly, d0, d1, holes=(), circles=(),
                 material="ply", color=(0.86, 0.72, 0.52), cut=None, qty=1,
                 note="", phase=1):
        self.name, self.plane, self.poly = name, plane, [tuple(p) for p in poly]
        self.d0, self.d1 = d0, d1
        self.holes = [list(h) for h in holes]
        self.circles = list(circles)          # (cu, cv, r)
        self.material, self.color, self.cut, self.qty = material, color, cut, qty
        self.note, self.phase = note, phase

    def to3d(self, u, v, d):
        if self.plane == "xz": return (u, d, v)
        if self.plane == "yz": return (d, u, v)
        return (u, v, d)

    def all_holes(self, n=40):
        hs = [list(h) for h in self.holes]
        for cu, cv, r in self.circles:
            hs.append([(cu + r * math.cos(2 * math.pi * k / n),
                        cv + r * math.sin(2 * math.pi * k / n)) for k in range(n)])
        return hs

    def faces(self):
        """list of (outer3d, [holes3d]) planar faces."""
        out = []
        hs = self.all_holes()
        for d in (self.d0, self.d1):
            out.append(([self.to3d(u, v, d) for u, v in self.poly],
                        [[self.to3d(u, v, d) for u, v in h] for h in hs]))
        P = self.poly
        for i in range(len(P)):
            (u0, v0), (u1, v1) = P[i], P[(i + 1) % len(P)]
            out.append(([self.to3d(u0, v0, self.d0), self.to3d(u1, v1, self.d0),
                         self.to3d(u1, v1, self.d1), self.to3d(u0, v0, self.d1)], []))
        for h in hs:                                  # hole side walls
            for i in range(len(h)):
                (u0, v0), (u1, v1) = h[i], h[(i + 1) % len(h)]
                out.append(([self.to3d(u0, v0, self.d0), self.to3d(u1, v1, self.d0),
                             self.to3d(u1, v1, self.d1), self.to3d(u0, v0, self.d1)], []))
        return out

    def area(self):
        def a(p):
            return 0.5 * abs(sum(p[i][0] * p[(i+1) % len(p)][1] - p[(i+1) % len(p)][0] * p[i][1]
                                 for i in range(len(p))))
        return a(self.poly) - sum(a(h) for h in self.holes) - sum(math.pi * r * r for *_, r in self.circles)

    def volume(self):
        return self.area() * (self.d1 - self.d0)

    def centroid(self):
        p = np.array(self.poly)
        u, v = p[:, 0].mean(), p[:, 1].mean()
        return np.array(self.to3d(u, v, (self.d0 + self.d1) / 2))

def rect(u0, v0, u1, v1):
    return [(u0, v0), (u1, v0), (u1, v1), (u0, v1)]

WOOD   = (0.87, 0.74, 0.55)
WOOD_D = (0.78, 0.62, 0.43)
ROOF   = (0.55, 0.42, 0.36)
PINE   = (0.93, 0.83, 0.62)
PLA    = (0.25, 0.55, 0.72)

def build_parts():
    P = []
    P.append(Part("Base", "xy", rect(BASE_X0, BASE_Y0, BASE_X1, BASE_Y1), -T, 0,
                  color=WOOD_D, cut=(BASE_X1 - BASE_X0, BASE_Y1 - BASE_Y0),
                  note="Ground floor + front doorstep + 2\" back porch + elevator footing"))
    # side walls (polygon in y,z). Left has two windows.
    lw = [rect(3.5, 2.5, 7.5, 6.5), rect(3.5, Z_MID + T + 2.5, 7.5, Z_MID + T + 6.5)]
    P.append(Part("Left side wall", "yz", rect(T, 0, D, Z_SIDE), 0, T, holes=lw,
                  color=WOOD, cut=(Z_SIDE, D - T),
                  note=f"Dado {T:.3f} wide x {DADO} deep on INSIDE face, bottom edge at {Z_MID}\""))
    P.append(Part("Right side wall", "yz", rect(T, 0, D, Z_SIDE), W - T, W,
                  color=WOOD, cut=(Z_SIDE, D - T),
                  note=f"Dado on INSIDE face (mirror of left) + guide groove on OUTSIDE face"))
    P.append(Part("Middle floor", "xy", rect(T - DADO, T, W - T + DADO, D), Z_MID, Z_MID + T,
                  color=WOOD, cut=(W - 2 * T + 2 * DADO, D - T), note="Rides in the side-wall dadoes"))
    P.append(Part("Attic floor", "xy", rect(0, T, W, D), Z_SIDE, Z_ATTIC,
                  color=WOOD, cut=(W, D - T), note="Sits on top of both side walls"))
    # facade
    door = [(3.868, 0), (8.368, 0), (8.368, 6.0), (7.868, 6.5), (4.368, 6.5), (3.868, 6.0)]
    xl, xr = (T + X_DIV) / 2, (X_DIV + T + W - T) / 2
    fac_holes = [door, rect(xr - 2, 3, xr + 2, 7),
                 rect(xl - 2, Z_MID + T + 2.5, xl + 2, Z_MID + T + 6.5),
                 rect(xr - 2, Z_MID + T + 2.5, xr + 2, Z_MID + T + 6.5)]
    P.append(Part("Front facade", "xz",
                  [(0, 0), (W, 0), (W, Z_ATTIC), (W / 2, Z_RIDGE), (0, Z_ATTIC)], 0, T,
                  holes=fac_holes, circles=[(W / 2, Z_ATTIC + 3.2, 1.75)],
                  color=WOOD, cut=(W, Z_RIDGE),
                  note=f"Pentagon; gable slope {PITCH_DEG:.1f} deg; door, 3 windows, round attic window"))
    # dividers (y,z polygons) with walk-through doorways
    dv = lambda z0: [(T, z0), (D, z0), (D, z0 + ROOM_H), (T, z0 + ROOM_H)]
    dd = lambda z0: [(3.5, z0), (7.5, z0), (7.5, z0 + 5.6), (7.1, z0 + 6.0), (3.9, z0 + 6.0), (3.5, z0 + 5.6)]
    P.append(Part("Divider, ground", "yz", dv(0), X_DIV, X_DIV + T, holes=[dd(0)],
                  color=WOOD, cut=(ROOM_H, D - T), note="4\" x 6\" doorway from bottom edge"))
    P.append(Part("Divider, upper", "yz", dv(Z_MID + T), X_DIV, X_DIV + T, holes=[dd(Z_MID + T)],
                  color=WOOD, cut=(ROOM_H, D - T), note="Same as ground divider"))
    # rear gable frame
    zc = Z_ATTIC + CLEAT_W * SLOPE
    off = 1.5
    dz = off / math.cos(THETA)
    xi = (Z_ATTIC + off - (Z_ATTIC - dz)) / SLOPE
    frame_hole = [(xi, Z_ATTIC + off), (W - xi, Z_ATTIC + off), (W / 2, Z_RIDGE - dz)]
    P.append(Part("Rear gable frame", "xz",
                  [(CLEAT_W, Z_ATTIC), (W - CLEAT_W, Z_ATTIC), (W - CLEAT_W, zc), (W / 2, Z_RIDGE), (CLEAT_W, zc)],
                  D - T, D, holes=[frame_hole], color=WOOD,
                  cut=(W - 2 * CLEAT_W, Z_RIDGE - Z_ATTIC),
                  note="Triangle frame, 1.5\" border; keeps the attic open from behind"))
    # eave cleats (pine), triangular section
    P.append(Part("Eave cleat, left", "xz", [(0, Z_ATTIC), (CLEAT_W, Z_ATTIC), (CLEAT_W, zc)], T, D,
                  material="pine", color=PINE, cut=(D - T, CLEAT_W),
                  note=f"Rip from a long 1x2 stood on edge, blade at {PITCH_DEG:.1f} deg, then crosscut"))
    P.append(Part("Eave cleat, right", "xz", [(W, Z_ATTIC), (W - CLEAT_W, Z_ATTIC), (W - CLEAT_W, zc)], T, D,
                  material="pine", color=PINE, cut=(D - T, CLEAT_W), note="Mirror of left"))
    # roof panels: plumb cut at eave (x=0) and ridge (x=W/2)
    tz = T / math.cos(THETA)                  # vertical thickness of a sloped board
    L = [(0, Z_ATTIC), (W / 2, Z_RIDGE), (W / 2, Z_RIDGE + tz), (0, Z_ATTIC + tz)]
    R = [(W - x, z) for x, z in L]
    slope_len = (W / 2) / math.cos(THETA)
    P.append(Part("Roof panel, left", "xz", L, -FRONT_OH, D, color=ROOF,
                  cut=(slope_len + T * math.tan(THETA), D + FRONT_OH),
                  note=f"Both ends bevelled {PITCH_DEG:.1f} deg, PARALLEL (plumb cuts). Short point {slope_len:.3f}\""))
    P.append(Part("Roof panel, right", "xz", R, -FRONT_OH, D, color=ROOF,
                  cut=(slope_len + T * math.tan(THETA), D + FRONT_OH), note="Mirror of left"))
    # elevator shaft (phase 2 wood, but cut with everything else)
    P.append(Part("Shaft front panel", "xz", rect(W, 0, SH_X1 + T, Z_ATTIC), SH_Y0 - T, SH_Y0,
                  color=WOOD, cut=(Z_ATTIC, SHAFT + T), phase=2, note="Closes the front of the shaft"))
    P.append(Part("Shaft outer panel", "yz", rect(SH_Y0, 0, D, Z_ATTIC), SH_X1, SH_X1 + T,
                  color=WOOD, cut=(Z_ATTIC, SHAFT), phase=2, note="Guide groove on inside face"))
    # printed elevator parts (for checks & render)
    cx0 = W + (SHAFT - CAR) / 2
    cy0 = D - CAR - 0.125
    P.append(Part("Elevator car (printed)", "xy", rect(cx0, cy0, cx0 + CAR, cy0 + CAR), 0, CAR_H,
                  material="PLA", color=PLA, phase=2))
    P.append(Part("Winch housing (printed)", "xy", rect(W, SH_Y0 - T, SH_X1 + T, D), Z_ATTIC, Z_ATTIC + 2.5,
                  material="PLA", color=PLA, phase=2))
    P.append(Part("Car stop block", "xy", rect(SH_X1 - 0.75, SH_Y0, SH_X1, SH_Y0 + 0.5),
                  Z_MID + T + CAR_H + 0.03, Z_MID + T + CAR_H + 0.78,
                  material="ply-scrap", color=WOOD_D, phase=2, note="Glued in front-outer corner of shaft"))
    return P

# ------------------------------------------------------------ geometry check
def point_in_poly(pt, poly):
    x, y = pt; inside = False
    n = len(poly)
    for i in range(n):
        x1, y1 = poly[i]; x2, y2 = poly[(i + 1) % n]
        if (y1 > y) != (y2 > y):
            xin = x1 + (y - y1) * (x2 - x1) / (y2 - y1)
            if x < xin: inside = not inside
    return inside

def to_local(part, p):
    x, y, z = p
    if part.plane == "xz": return (x, z), y
    if part.plane == "yz": return (y, z), x
    return (x, y), z

def solid_contains(part, p, eps=0.02):
    """inside the solid material (holes excluded), shrunk by eps"""
    (u, v), d = to_local(part, p)
    if not (part.d0 + eps < d < part.d1 - eps): return False
    if not point_in_poly((u, v), part.poly): return False
    # shrink: test 4 nudged points too
    for du, dv in ((eps, 0), (-eps, 0), (0, eps), (0, -eps)):
        if not point_in_poly((u + du, v + dv), part.poly): return False
    for h in part.all_holes():
        if point_in_poly((u, v), h): return False
    return True

def sample_points(part, step=0.2):
    pts = []
    P = np.array(part.poly)
    u0, v0 = P.min(0); u1, v1 = P.max(0)
    for d in np.arange(part.d0 + step / 2, part.d1, step):
        for u in np.arange(u0 + step / 2, u1, step):
            for v in np.arange(v0 + step / 2, v1, step):
                pt = part.to3d(u, v, d)
                if solid_contains(part, pt, 0.0):
                    pts.append(pt)
    return pts

EXPECTED_OVERLAP = {("Left side wall", "Middle floor"), ("Right side wall", "Middle floor")}

def interference_check(parts):
    rows = []
    samples = {p.name: sample_points(p, 0.12 if (p.d1 - p.d0) < 1 else 0.25) for p in parts}
    for i, a in enumerate(parts):
        for b in parts[i + 1:]:
            hits = sum(1 for pt in samples[a.name] if solid_contains(b, pt))
            hits += sum(1 for pt in samples[b.name] if solid_contains(a, pt))
            key = (a.name, b.name)
            if hits:
                rows.append((a.name, b.name, hits, key in EXPECTED_OVERLAP or key[::-1] in EXPECTED_OVERLAP))
    return rows

# --------------------------------------------------------------- renderer
def render(parts, view_dir, fname, size=(1100, 900), ss=2, light=(-0.4, -0.7, 0.9), pad=40):
    from matplotlib.path import Path
    from PIL import Image  # pillow ships with matplotlib
    d = np.array(view_dir, float); d /= np.linalg.norm(d)        # points from scene toward eye
    up = np.array([0, 0, 1.0]); right = np.cross(up, d); right /= np.linalg.norm(right)
    up2 = np.cross(d, right)
    Lv = np.array(light, float); Lv /= np.linalg.norm(Lv)
    faces = []
    for pi, p in enumerate(parts):
        for outer, holes in p.faces():
            faces.append((np.array(outer), [np.array(h) for h in holes], p.color, pi))
    allpts = np.vstack([f[0] for f in faces])
    sx = allpts @ right; sy = allpts @ up2
    Wpx, Hpx = size[0] * ss, size[1] * ss
    scale = min((Wpx - 2 * pad * ss) / (sx.max() - sx.min()), (Hpx - 2 * pad * ss) / (sy.max() - sy.min()))
    ox = (Wpx - (sx.max() - sx.min()) * scale) / 2 - sx.min() * scale
    oy = (Hpx - (sy.max() - sy.min()) * scale) / 2 + sy.max() * scale
    proj = lambda P: np.stack([P @ right * scale + ox, oy - (P @ up2) * scale], 1)
    zbuf = np.full((Hpx, Wpx), -np.inf); img = np.ones((Hpx, Wpx, 3)); fid = np.full((Hpx, Wpx), -1)
    for k, (outer, holes, col, pi) in enumerate(faces):
        n = np.cross(outer[1] - outer[0], outer[2] - outer[0])
        if np.linalg.norm(n) < 1e-9: continue
        n /= np.linalg.norm(n)
        if n @ d < 0: n = -n
        if abs(n @ d) < 1e-6: continue
        shade = 0.72 + 0.32 * max(0.0, n @ Lv) + 0.06 * (n @ d)
        c = np.clip(np.array(col) * min(shade, 1.08), 0, 1)
        P2 = proj(outer)
        hole_paths = [Path(proj(h)) for h in holes]
        path = Path(P2)
        x0, y0 = np.floor(P2.min(0)).astype(int); x1, y1 = np.ceil(P2.max(0)).astype(int)
        x0, y0 = max(x0, 0), max(y0, 0); x1, y1 = min(x1, Wpx - 1), min(y1, Hpx - 1)
        if x1 <= x0 or y1 <= y0: continue
        gx, gy = np.meshgrid(np.arange(x0, x1 + 1) + 0.5, np.arange(y0, y1 + 1) + 0.5)
        pts = np.stack([gx.ravel(), gy.ravel()], 1)
        inside = path.contains_points(pts)
        for hp in hole_paths:
            inside &= ~hp.contains_points(pts)
        inside = inside.reshape(gx.shape)
        if not inside.any(): continue
        # depth along d: solve plane n.(X - X0) = 0 for X = a*right + b*up2 + t*d
        X0 = outer[0]
        a = (gx - ox) / scale; b = (oy - gy) / scale
        nd = n @ d
        t = (n @ X0 - a * (n @ right) - b * (n @ up2)) / nd
        sub = zbuf[y0:y1 + 1, x0:x1 + 1]
        m = inside & (t > sub + 1e-4)
        sub[m] = t[m]
        img[y0:y1 + 1, x0:x1 + 1][m] = c
        fid[y0:y1 + 1, x0:x1 + 1][m] = k
    edge = np.zeros(fid.shape, bool)
    edge[:-1, :] |= fid[:-1, :] != fid[1:, :]
    edge[:, :-1] |= fid[:, :-1] != fid[:, 1:]
    img[edge] = img[edge] * 0.35
    im = Image.fromarray((img * 255).astype(np.uint8)).resize(size, Image.LANCZOS)
    im.save(fname, optimize=True)
    return fname

# -------------------------------------------------------------- sheet layout
# hand-placed nest on one 60" x 60" sheet: (part name, x, y, w, h)  (w,h = cut size as drawn)
def sheet_layout(parts):
    cut = {p.name: p.cut for p in parts if p.material == "ply" and p.cut}
    def r(name, x, y, rot=False):
        a, b = cut[name]
        w, h = (b, a) if rot else (a, b)
        return (name, x, y, w, h)
    g = 0.25
    L = []
    L.append(r("Front facade", 0, 0))                                     # 24 x 26.94
    L.append(r("Roof panel, left", 24 + g, 0))                            # 14.74 x 11
    L.append(r("Roof panel, right", L[-1][1] + L[-1][3] + g, 0))
    L.append(r("Rear gable frame", 24 + g, 11 + g))                        # 22 x 8
    L.append(r("Divider, ground", 46.5, 11 + g, rot=True))                 # 9.53 x 9
    L.append(r("Divider, upper", 46.5, 20.5, rot=True))
    L.append(r("Shaft front panel", 24 + g, 19.5))                         # 18.94 x 3.72
    L.append(r("Shaft outer panel", 24 + g, 19.5 + cut["Shaft front panel"][1] + g))
    L.append(r("Base", 0, cut["Front facade"][1] + g))                     # 29.25 x 11.5
    L.append(r("Left side wall", 29.5, 29.75))                             # 18.47 x 9.53
    L.append(r("Right side wall", 50.25, 29.75, rot=True))
    L.append(r("Attic floor", 0, L[8][2] + L[8][4] + g))
    L.append(r("Middle floor", 24 + g, L[8][2] + L[8][4] + g))
    return L

def check_layout(L):
    errs = []
    for n, x, y, w, h in L:
        if x < 0 or y < 0 or x + w > SHEET[0] + 1e-9 or y + h > SHEET[1] + 1e-9:
            errs.append(f"{n} leaves the sheet")
    for i in range(len(L)):
        for j in range(i + 1, len(L)):
            a, b = L[i], L[j]
            if (a[1] < b[1] + b[3] + KERF - 1e-9 and b[1] < a[1] + a[3] + KERF - 1e-9 and
                    a[2] < b[2] + b[4] + KERF - 1e-9 and b[2] < a[2] + a[4] + KERF - 1e-9):
                errs.append(f"{a[0]} too close to / overlaps {b[0]}")
    return errs

def frac(x, den=32):
    """inches -> nearest 1/32 string"""
    n = round(x * den); whole, rem = divmod(n, den)
    if rem == 0: return f"{whole}\""
    g = math.gcd(rem, den)
    return (f"{whole}-" if whole else "") + f"{rem // g}/{den // g}\""

def svg_sheet(L, fname):
    s = 11  # px per inch
    W_, H_ = SHEET[0] * s, SHEET[1] * s
    o = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="-10 -10 {W_ + 20} {H_ + 20}" '
         f'font-family="ui-monospace,Menlo,Consolas,monospace" role="img" aria-label="Sheet cutting layout">',
         f'<rect x="0" y="0" width="{W_}" height="{H_}" fill="var(--sheet,#f3ead9)" stroke="var(--ink,#333)" stroke-width="2"/>']
    for n, x, y, w, h in L:
        o.append(f'<rect x="{x*s:.1f}" y="{y*s:.1f}" width="{w*s:.1f}" height="{h*s:.1f}" '
                 f'fill="var(--part,#e2c89f)" stroke="var(--ink,#333)" stroke-width="1.5"/>')
        fs = 11 if min(w, h) > 5 else 9
        cxp, cyp = (x + w / 2) * s, (y + h / 2) * s
        rot = f' transform="rotate(-90 {cxp:.1f} {cyp:.1f})"' if h > w * 1.6 else ""
        o.append(f'<text x="{cxp:.1f}" y="{cyp - 3:.1f}" text-anchor="middle" font-size="{fs}" fill="var(--ink,#333)"{rot}>{n}</text>')
        o.append(f'<text x="{cxp:.1f}" y="{cyp + fs + 1:.1f}" text-anchor="middle" font-size="{fs - 1}" fill="var(--muted,#666)"{rot}>{frac(w)} × {frac(h)}</text>')
    o.append(f'<text x="{W_/2}" y="{H_ - 8}" text-anchor="middle" font-size="12" fill="var(--muted,#666)">'
             f'offcut strip: dado test pieces, stop block, spares</text>')
    o.append("</svg>")
    open(fname, "w").write("\n".join(o))

def svg_facade(parts, fname):
    f = next(p for p in parts if p.name == "Front facade")
    s = 18; pad = 60; padl = 120; padr = 110
    Wd, Hd = W * s + padl + padr, Z_RIDGE * s + 2 * pad
    X = lambda x: padl + x * s
    Y = lambda z: pad + (Z_RIDGE - z) * s
    poly = " ".join(f"{X(u):.1f},{Y(v):.1f}" for u, v in f.poly)
    o = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {Wd:.0f} {Hd:.0f}" font-family="ui-monospace,Menlo,Consolas,monospace" role="img" aria-label="Facade cutting drawing">',
         f'<polygon points="{poly}" fill="var(--part,#e2c89f)" stroke="var(--ink,#333)" stroke-width="2"/>']
    for h in f.all_holes():
        o.append('<polygon points="' + " ".join(f"{X(u):.1f},{Y(v):.1f}" for u, v in h) +
                 '" fill="var(--bg2,#fff)" stroke="var(--ink,#333)" stroke-width="1.5"/>')
    # floor lines (dashed) for reference
    for z, lab in ((Z_MID, "mid floor"), (Z_MID + T, None), (Z_SIDE, "attic floor"), (Z_ATTIC, None)):
        o.append(f'<line x1="{X(0)}" y1="{Y(z):.1f}" x2="{X(W)}" y2="{Y(z):.1f}" stroke="var(--accent,#2a6f97)" stroke-dasharray="5 4" stroke-width="1"/>')
        if lab:
            o.append(f'<text x="{X(W) + 6}" y="{Y(z) - 2:.1f}" font-size="11" fill="var(--accent,#2a6f97)">{lab}</text>')
    for x in (X_DIV, X_DIV + T):
        o.append(f'<line x1="{X(x):.1f}" y1="{Y(0)}" x2="{X(x):.1f}" y2="{Y(Z_SIDE):.1f}" stroke="var(--accent,#2a6f97)" stroke-dasharray="5 4" stroke-width="1"/>')
    def dim_h(x0, x1, z, text, off=-26):
        y = Y(z) - off
        o.append(f'<line x1="{X(x0):.1f}" y1="{y:.1f}" x2="{X(x1):.1f}" y2="{y:.1f}" stroke="var(--ink,#333)" stroke-width="1" marker-start="url(#a)" marker-end="url(#a)"/>')
        o.append(f'<text x="{(X(x0)+X(x1))/2:.1f}" y="{y - 5:.1f}" text-anchor="middle" font-size="12" fill="var(--ink,#333)">{text}</text>')
    def dim_v(x, z0, z1, text, off=-30):
        xx = X(x) + off
        o.append(f'<line x1="{xx:.1f}" y1="{Y(z0):.1f}" x2="{xx:.1f}" y2="{Y(z1):.1f}" stroke="var(--ink,#333)" stroke-width="1" marker-start="url(#a)" marker-end="url(#a)"/>')
        o.append(f'<text x="{xx - 6:.1f}" y="{(Y(z0)+Y(z1))/2:.1f}" text-anchor="end" font-size="12" fill="var(--ink,#333)">{text}</text>')
    o.insert(1, '<defs><marker id="a" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 2 L5 5 L0 8" fill="none" stroke="var(--ink,#333)"/></marker></defs>')
    dim_h(0, W, 0, frac(W), off=-28)
    dim_v(0, 0, Z_ATTIC, frac(Z_ATTIC), off=-10)
    dim_v(0, Z_ATTIC, Z_RIDGE, frac(RISE), off=-10)
    o.append(f'<text x="{X(W/2)}" y="{Y(Z_RIDGE) - 14}" text-anchor="middle" font-size="12" fill="var(--ink,#333)">gable {PITCH_DEG:.1f}° (8:12)</text>')
    o.append(f'<text x="{X(6.118)}" y="{Y(7.2)}" text-anchor="middle" font-size="11" fill="var(--muted,#666)">door 4½×6½</text>')
    o.append(f'<text x="{X(17.88)}" y="{Y(7.7)}" text-anchor="middle" font-size="11" fill="var(--muted,#666)">4×4 windows</text>')
    o.append(f'<text x="{X(12)}" y="{Y(Z_ATTIC + 3.2) + 48}" text-anchor="middle" font-size="11" fill="var(--muted,#666)">3½ dia</text>')
    o.append("</svg>")
    open(fname, "w").write("\n".join(o))

def svg_side(fname):
    """right side wall, viewed from OUTSIDE (shows guide groove) + section of dado"""
    s = 26; pad = 60
    Wd, Hd = (D - T) * s + 2 * pad + 300, Z_SIDE * s + 2 * pad + 40
    X = lambda y: pad + (y - T) * s
    Y = lambda z: pad + (Z_SIDE - z) * s
    o = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {Wd:.0f} {Hd:.0f}" font-family="ui-monospace,Menlo,Consolas,monospace" role="img" aria-label="Side wall drawing">',
         '<defs><marker id="b" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 2 L5 5 L0 8" fill="none" stroke="var(--ink,#333)"/></marker></defs>',
         f'<rect x="{X(T)}" y="{Y(Z_SIDE)}" width="{(D-T)*s:.1f}" height="{Z_SIDE*s:.1f}" fill="var(--part,#e2c89f)" stroke="var(--ink,#333)" stroke-width="2"/>']
    gy = D - 0.125 - CAR / 2
    o.append(f'<rect x="{X(gy - GROOVE_W/2):.1f}" y="{Y(Z_SIDE)}" width="{GROOVE_W*s:.1f}" height="{Z_SIDE*s:.1f}" fill="var(--accent,#2a6f97)" opacity=".55"/>')
    o.append(f'<rect x="{X(T)}" y="{Y(Z_MID + T):.1f}" width="{(D-T)*s:.1f}" height="{T*s:.1f}" fill="none" stroke="var(--accent2,#b5482d)" stroke-dasharray="6 4" stroke-width="1.5"/>')
    o.append(f'<text x="{X(T) + 8}" y="{Y(Z_MID) + 16:.1f}" font-size="12" fill="var(--accent2,#b5482d)">dado, inside face</text>')
    o.append(f'<text x="{X(T) + 8}" y="{Y(Z_MID) + 31:.1f}" font-size="12" fill="var(--accent2,#b5482d)">(hidden, both walls)</text>')
    zl = Z_SIDE * 0.8
    o.append(f'<text x="{X(gy) - 10:.1f}" y="{Y(zl):.1f}" font-size="12" text-anchor="end" fill="var(--accent,#2a6f97)">guide groove</text>')
    o.append(f'<text x="{X(gy) - 10:.1f}" y="{Y(zl) + 15:.1f}" font-size="11" text-anchor="end" fill="var(--accent,#2a6f97)">¼ wide × 3/16 deep</text>')
    o.append(f'<text x="{X(gy) - 10:.1f}" y="{Y(zl) + 30:.1f}" font-size="11" text-anchor="end" fill="var(--accent,#2a6f97)">outside face,</text>')
    o.append(f'<text x="{X(gy) - 10:.1f}" y="{Y(zl) + 45:.1f}" font-size="11" text-anchor="end" fill="var(--accent,#2a6f97)">right wall only</text>')
    # dims
    xx = X(D) + 30
    for z0, z1, t in ((0, Z_MID, frac(Z_MID)), (Z_MID, Z_MID + T, "T"), (0, Z_SIDE, frac(Z_SIDE))):
        off = 0 if t != frac(Z_SIDE) else 70
        o.append(f'<line x1="{xx+off}" y1="{Y(z0):.1f}" x2="{xx+off}" y2="{Y(z1):.1f}" stroke="var(--ink,#333)" marker-start="url(#b)" marker-end="url(#b)"/>')
        o.append(f'<text x="{xx + off + 6}" y="{(Y(z0)+Y(z1))/2 + 4:.1f}" font-size="12" fill="var(--ink,#333)">{t}</text>')
    o.append(f'<line x1="{X(T)}" y1="{Y(0) + 22}" x2="{X(D)}" y2="{Y(0) + 22}" stroke="var(--ink,#333)" marker-start="url(#b)" marker-end="url(#b)"/>')
    o.append(f'<text x="{(X(T)+X(D))/2}" y="{Y(0) + 40}" text-anchor="middle" font-size="12" fill="var(--ink,#333)">{frac(D-T)}</text>')
    o.append(f'<text x="{X(gy):.1f}" y="{Y(Z_SIDE) - 10}" text-anchor="middle" font-size="11" fill="var(--muted,#666)">{frac(D - gy)} from back edge to groove center</text>')
    o.append(f'<text x="{X(T)}" y="{Y(0) + 60}" font-size="11" fill="var(--muted,#666)">← front</text>')
    o.append(f'<text x="{X(D)}" y="{Y(0) + 60}" text-anchor="end" font-size="11" fill="var(--muted,#666)">open back →</text>')
    o.append("</svg>")
    open(fname, "w").write("\n".join(o))

# --------------------------------------------------------------- stability
def stability(parts, density_lb_ft3=42.0):
    """Baltic birch ~680 kg/m3 = ~42 lb/ft3; pine ~28."""
    m_tot = 0; mom = np.zeros(3)
    for p in parts:
        if p.material == "PLA":
            mass = 0.35   # lb, rough: car + winch
        else:
            dens = 28.0 if p.material == "pine" else density_lb_ft3
            mass = p.volume() / 1728 * dens
        m_tot += mass; mom += mass * p.centroid()
    cg = mom / m_tot
    h = Z_RIDGE + T / math.cos(THETA)
    # tipping backward (push on facade near ridge) pivots about back edge y = D
    # tipping forward (kid pulls ridge toward self from the open back... i.e. toward -y) pivots about y = BASE_Y0
    f_back = m_tot * (BASE_Y1 - cg[1]) / (h + T)
    f_fwd = m_tot * (cg[1] - BASE_Y0) / (h + T)
    f_side = m_tot * min(cg[0] - BASE_X0, BASE_X1 - cg[0]) / (h + T)
    return m_tot, cg, h, f_back, f_fwd, f_side

# ------------------------------------------------------------------- main
def main(render_imgs=True):
    parts = build_parts()
    print(f"Plywood T = {T}\"  pitch = {PITCH_DEG:.2f} deg  ridge (underside) z = {Z_RIDGE:.3f}\"")
    print("\nCUT LIST")
    rows = []
    for p in parts:
        if not p.cut: continue
        rows.append([p.name, p.material, f"{p.cut[0]:.3f}", f"{p.cut[1]:.3f}", frac(p.cut[0]), frac(p.cut[1]), p.qty, p.phase, p.note])
        print(f"  {p.name:<20} {p.material:<5} {p.cut[0]:7.3f} x {p.cut[1]:7.3f}  ({frac(p.cut[0])} x {frac(p.cut[1])})")
    with open(os.path.join(ROOT, "docs", "cutlist.csv"), "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["part", "material", "length_in", "width_in", "length_frac", "width_frac", "qty", "phase", "notes"])
        w.writerows(rows)

    print("\nINTERFERENCE CHECK (sampled)")
    bad = 0
    for a, b, hits, expected in interference_check(parts):
        tag = "expected (dado)" if expected else "*** UNEXPECTED ***"
        if not expected: bad += 1
        print(f"  {a} <-> {b}: {hits} sample hits  {tag}")
    print(f"  unexpected interferences: {bad}")

    L = sheet_layout(parts)
    errs = check_layout(L)
    used = sum(w * h for _, _, _, w, h in L)
    print(f"\nSHEET LAYOUT: {len(L)} plywood pieces on {SHEET[0]:.0f}x{SHEET[1]:.0f}, "
          f"{100*used/(SHEET[0]*SHEET[1]):.0f}% used, errors: {errs or 'none'}")

    m, cg, h, fb, ff, fs = stability(parts)
    print(f"\nSTABILITY: est. weight {m:.1f} lb, CG at x={cg[0]:.1f} y={cg[1]:.1f} z={cg[2]:.1f}, height {h:.1f}\"")
    print(f"  horizontal push at the ridge to tip: backward {fb:.1f} lb, forward {ff:.1f} lb, sideways {fs:.1f} lb")

    # elevator checks
    car = next(p for p in parts if p.name.startswith("Elevator car"))
    stop = next(p for p in parts if p.name == "Car stop block")
    top_floor = Z_MID + T
    car_top_floor_level = stop.d0 - CAR_H
    gap_side = (SHAFT - CAR) / 2
    tab_reach = gap_side + 0.15
    print("\nELEVATOR")
    print(f"  side clearance car<->wall {gap_side:.3f}\" ({gap_side*25.4:.1f} mm) - must stay < 0.19\" (finger-trap band 0.19-0.375\")")
    print(f"  tab into groove {0.15:.3f}\" of {GROOVE_D}\" groove -> bottom clearance {GROOVE_D-0.15:.3f}\"")
    print(f"  car floor at top stop {car_top_floor_level:.3f}\" vs upper floor {top_floor:.3f}\" (step {car_top_floor_level-top_floor:+.3f}\")")
    print(f"  travel {car_top_floor_level:.2f}\" -> drum turns at 1.0\" dia core: {car_top_floor_level/(math.pi*1.0):.1f}")

    if render_imgs:
        render(parts, (-1.0, -1.25, 0.85), os.path.join(ROOT, "img", "iso_front.png"))
        render(parts, (1.15, 1.25, 0.8), os.path.join(ROOT, "img", "iso_back.png"))
        build = [p for p in parts if p.phase == 1]
        render(build, (1.15, 1.25, 0.8), os.path.join(ROOT, "img", "iso_back_phase1.png"))
    svg_sheet(L, os.path.join(ROOT, "img", "sheet_layout.svg"))
    svg_facade(parts, os.path.join(ROOT, "img", "facade.svg"))
    svg_side(os.path.join(ROOT, "img", "side_wall.svg"))
    return parts, L, bad, errs

if __name__ == "__main__":
    _, _, bad, errs = main(render_imgs="--no-render" not in sys.argv)
    sys.exit(1 if (bad or errs) else 0)
