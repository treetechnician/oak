# Clubhouse Dollhouse

A two-storey plywood dollhouse with four rooms, an open attic and a hand-cranked elevator. It's sized for ~3" licensed character figures. Phase 1 is the woodworking. Phase 2 adds 3D-printed parts: the elevator car and winch, furniture, and a nameplate.

**Open [`index.html`](index.html)** for the full build tour. It covers the bill of materials, cut list, sheet layout, drawings, assembly steps, printed parts, safety checklist and design checks. With GitHub Pages enabled on this repo, that page is the site.

![Back view](img/iso_back.png)

## What's here

| Path | What |
|---|---|
| `index.html` | Self-contained build tour (images embedded) |
| `tools/house_model.py` | **Source of truth.** Geometry, cut list, interference check, sheet nesting check, tip-over estimate, elevator clearances, drawings and renders |
| `tools/build_page.py` | Rebuilds `index.html` from the model and `page_template.html` |
| `cad/*.scad` | Parametric OpenSCAD drafts for the printed parts, plus a wood check model |
| `docs/cutlist.csv` | Cut list for the shop |
| `img/` | Generated renders and SVG drawings |

## Regenerate

```bash
# measure your plywood, set T at the top of tools/house_model.py, then:
python3 tools/house_model.py      # prints checks, writes cutlist + drawings + renders
python3 tools/build_page.py       # rebuilds index.html
```

The only requirements are `numpy` and `matplotlib` (Pillow ships with matplotlib). `house_model.py` exits non-zero if it finds an unexpected part interference or a sheet-layout error.

## Printed parts

Open a file in [OpenSCAD](https://openscad.org), set `part = "..."`, render with F6, and export the STL. These are **Rev A drafts**: they haven't been rendered or test-printed yet. The parts are sized for a 220 × 220 × 250 mm bed (Ender-3 V3 SE/KE/V3), and every part is too large to pass the 1¼" small-parts cylinder.

## Notes

- The theme comes from store-bought licensed figures and decals. The geometry in this repo is original.
- `cad/nameplate.scad` defaults to `CLUBHOUSE`. Set your kid's name locally and don't commit it.
- Units: the house is in inches. Printed parts are in millimetres (`IN = 25.4` converts).

Rev A draft · Oct 2026
