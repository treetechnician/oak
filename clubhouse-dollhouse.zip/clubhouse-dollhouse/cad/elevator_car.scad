// elevator_car.scad - Phase 2. Open-back elevator car for ~3" figures.
// The car rides in the plywood shaft on the house's right side; two full-height
// tabs run in 1/4" grooves so the car can't be pulled out of the open back.
//
// PRINT: open face DOWN on the bed (print_orient = true). No supports needed
//        except, if your first print shows droop, "supports: touching build plate"
//        under the two tabs only.  PLA, 0.2 mm layers, 4 walls, 20% gyroid.
//
// Installed coordinates (print_orient = false):
//   x = across the shaft, y = toward the open back (+y open), z = up.

include <common.scad>

print_orient = true;

SILL_H    = 0.25 * IN;          // little lip so figures don't slide out the back
EYE_W     = 14;                 // cord anchor block width (x)
EYE_H     = 10;                 // anchor block height above the roof
EYE_HOLE  = 4.5;                // hole for #18 braided mason line
TAB_W     = 5.0;                                  // tab thickness (y), groove is 6.35
TAB_OUT   = (SHAFT - CAR) / 2 + 0.15 * IN;        // reaches 0.15" into the groove
TAB_Y     = CAR / 2 - TAB_W / 2;                  // tabs centred on the car depth

module car_body() {
    difference() {
        rbox_flat([CAR, CAR, CAR_H]);
        // hollow, open toward +y, leaving floor, roof, two sides and the back wall
        translate([WALL, WALL, WALL]) cube([CAR - 2 * WALL, CAR, CAR_H - 2 * WALL]);
    }
    // sill along the open edge
    translate([WALL, CAR - WALL, WALL - 0.01]) cube([CAR - 2 * WALL, WALL, SILL_H]);
}

module guide_tabs() {
    for (side = [0, 1])
        translate([side == 0 ? -TAB_OUT : CAR - 0.01, TAB_Y, 0])
            hull() {
                // rounded vertical rib, full car height
                translate([0, 0, 2]) cube([TAB_OUT + 0.01, TAB_W, CAR_H - 4]);
                translate([side == 0 ? TAB_OUT - 1 : 0, 0, 0]) cube([1, TAB_W, CAR_H]);
            }
}

module cord_eye() {
    // spans the full car depth so it sits flat on the bed when printed on its back
    translate([CAR / 2 - EYE_W / 2, 0, CAR_H - 0.01])
        difference() {
            rbox_flat([EYE_W, CAR, EYE_H], r = 1.2);
            translate([-1, CAR / 2, EYE_H / 2]) rotate([0, 90, 0])
                cylinder(d = EYE_HOLE, h = EYE_W + 2);
        }
}

module elevator_car() {
    car_body();
    guide_tabs();
    cord_eye();
}

if (print_orient)
    // open face (+y) down onto the bed
    translate([0, 0, CAR]) rotate([-90, 0, 0]) elevator_car();
else
    elevator_car();
