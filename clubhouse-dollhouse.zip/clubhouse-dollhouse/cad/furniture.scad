// furniture.scad - original chunky furniture sized for ~3" figures.
// Every piece is solid-sided (no thin legs to snap) and too big for the
// small-parts cylinder.  Set `part` and export each as its own STL.
//
// PRINT: PLA, 0.2 mm layers, 3 walls, 15-20% infill, no supports.
//        Sand any stringy corners before handing them over.

include <common.scad>

part = "all";   // table | chair | bed | slide | all

// ---------------------------------------------------------------- table
module table() {
    TW = 76; TD = 50; TH = 38; TOP = 6;
    translate([0, 0, TH - TOP]) rbox_flat([TW, TD, TOP], r = 2.5);
    // two slab ends instead of four legs
    for (x = [6, TW - 6 - 10])
        translate([x, 6, 0]) rbox_flat([10, TD - 12, TH - TOP + 1], r = 2);
}

// ---------------------------------------------------------------- chair
module chair() {
    CW = 38; CD = 38; SEAT_Z = 22; BACK_H = 58;
    // solid side panels
    for (x = [0, CW - 6])
        rbox_flat([6, CD, SEAT_Z + 4], r = 2);
    translate([0, 0, SEAT_Z]) rbox_flat([CW, CD, 6], r = 2);            // seat
    translate([0, CD - 7, 0]) rbox_flat([CW, 7, BACK_H], r = 2.5);       // back
}

// ---------------------------------------------------------------- bed
module bed() {
    BL = 102; BWD = 58; BH = 22;
    rbox_flat([BL, BWD, BH], r = 3);                                    // mattress block
    rbox_flat([8, BWD, 50], r = 3);                                     // headboard
    translate([BL - 8, 0, 0]) rbox_flat([8, BWD, 32], r = 3);           // footboard
    translate([12, 8, BH - 1]) rbox_flat([22, BWD - 16, 8], r = 4);     // pillow
}

// ---------------------------------------------------------------- slide
// Printed on its side: the 2-D profile lies on the bed, 50 mm tall.
SL_LEN = 150; SL_H = 90; SL_W = 50; DECK = 32; RAIL = 6; CHUTE = 6;

function chute_z(t) = 14 + (SL_H - 14) * (1 + cos(180 * t)) / 2;  // smooth S-curve; 14 mm at the end keeps 8 mm under the chute
function chute_pts(off) =
    [for (i = [0 : 30]) let(t = i / 30) [DECK + t * (SL_LEN - DECK), chute_z(t) - off]];

module slide_profile(off = 0) {
    polygon(concat([[0, 0], [SL_LEN, 0]],
                   [for (k = [30 : -1 : 0]) chute_pts(off)[k]],
                   [[0, SL_H - off]]));
}

module slide() {
    difference() {
        linear_extrude(SL_W) offset(r = 2) offset(delta = -2) slide_profile();
        // chute channel between the two rails
        translate([0, 0, RAIL]) linear_extrude(SL_W - 2 * RAIL)
            difference() {
                translate([DECK - 1, 0]) square([SL_LEN, SL_H + 10]);
                slide_profile(CHUTE);
            }
        // ladder steps cut into the back face
        for (i = [0 : 3])
            translate([-1, 14 + i * 19, RAIL]) cube([7, 6, SL_W - 2 * RAIL]);
    }
}

// ---------------------------------------------------------------- layout
if (part == "table") table();
else if (part == "chair") chair();
else if (part == "bed") bed();
else if (part == "slide") slide();
else {
    table();
    translate([90, 0, 0]) chair();
    translate([0, 70, 0]) bed();
    translate([0, 150, 0]) slide();
}
