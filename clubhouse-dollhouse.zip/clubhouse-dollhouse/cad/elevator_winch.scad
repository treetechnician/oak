// elevator_winch.scad - Phase 2. Enclosed crank winch that sits on top of the
// elevator shaft (house right side, at the eave line).
//
// Parts (set `part` and export each as its own STL):
//   "housing"  - open-top box, screws down onto the shaft panel edges
//   "lid"      - closes the housing (4 x #4 x 1/2" pan-head screws)
//   "drum"     - cord drum with a hub tube that locates it against the +x wall
//   "crank"    - handle on the outside; glued to the axle
//   "assembly" - everything in place, for checking only (do not print)
//
// Hardware: 1/4" (6.35 mm) steel rod, 4-1/4" long (axle - ends inside the crank hub); one #010 silicone
//           O-ring (1/4" ID) as a friction brake between the crank hub and the
//           housing wall; 12" of #18 braided nylon mason line.
//
// Why friction and no ratchet: a 4-year-old can't work a pawl.  The O-ring
// gives enough drag to hold a ~60 g car + figure anywhere, and the car only
// ever hangs on the cord, so lowering it can't push down on anything.
//
// Housing local coordinates: x = 0 at the house's right wall (outer face),
// y = 0 at the shaft front panel's front face, z = 0 on the panel tops.

include <common.scad>

part = "assembly";   // housing | lid | drum | crank | assembly

HX = SHAFT + PLY_T;          // 94.5  housing footprint x
HY = SHAFT + PLY_T;          // 94.5  housing footprint y
HZ = 2.5 * IN;               // 63.5  housing height incl. lid
LID_T = 4;
FLOOR_T = 4;

AXLE_D   = 6.35;
AXLE_Z   = 33;                         // axle height above housing bottom
CORE_R   = 0.5 * IN;                   // 1.0" core dia -> ~3 turns of travel
FLANGE_R = 0.8 * IN;
// cord drops straight down over the car's eye: car centre in housing coords
CORD_X = (SHAFT - CAR) / 2 + CAR / 2;            // 41.3
CORD_Y = PLY_T + SHAFT - 0.125 * IN - CAR / 2;   // 50.7
AXLE_Y = CORD_Y + CORE_R;                         // cord leaves the -y side of the core

BOSS_R = 8; BOSS_T = 8;
DRUM_X0 = 22;                 // start of the drum (first flange)
DRUM_X1 = 60;                 // end of the cord section (second flange)
HUB_X1  = HX - WALL - BOSS_T - 0.5;   // hub tube stops 0.5 mm short of the inner boss

module housing() {
    difference() {
        union() {
            difference() {
                rbox_flat([HX, HY, HZ - LID_T]);
                translate([WALL, WALL, FLOOR_T]) cube([HX - 2 * WALL, HY - 2 * WALL, HZ]);
            }
            // bearing bosses, inside and outside of both x walls
            for (x = [WALL - 0.01, HX - WALL - BOSS_T + 0.01])
                translate([x, AXLE_Y, AXLE_Z]) rotate([0, 90, 0]) cylinder(r = BOSS_R, h = BOSS_T);
            translate([HX - 0.01, AXLE_Y, AXLE_Z]) rotate([0, 90, 0]) cylinder(r = BOSS_R, h = 4);
            // lid screw bosses in the four corners
            for (x = [WALL + 5, HX - WALL - 5], y = [WALL + 5, HY - WALL - 5])
                translate([x, y, 0]) cylinder(r = 5, h = HZ - LID_T);
        }
        // axle clearance hole straight through
        translate([-1, AXLE_Y, AXLE_Z]) rotate([0, 90, 0]) cylinder(d = AXLE_D + 0.6, h = HX + 10);
        // cord hole, chamfered both ends so the line can't fray
        translate([CORD_X, CORD_Y, -1]) cylinder(d = 7, h = FLOOR_T + 2);
        translate([CORD_X, CORD_Y, -0.01]) cylinder(d1 = 11, d2 = 7, h = 2);
        translate([CORD_X, CORD_Y, FLOOR_T - 1.99]) cylinder(d1 = 7, d2 = 11, h = 2);
        // pilot holes for #4 lid screws
        for (x = [WALL + 5, HX - WALL - 5], y = [WALL + 5, HY - WALL - 5])
            translate([x, y, HZ - LID_T - 14]) cylinder(d = 2.4, h = 15);
        // #6 countersunk mounting screws: 2 into the shaft front panel edge,
        // 1 into the shaft outer panel edge
        for (p = [[18, PLY_T / 2], [HX - 30, PLY_T / 2], [HX - PLY_T / 2, HY - 22]])
            translate([p[0], p[1], 0]) cs_hole_6(FLOOR_T, 30);   // head sits on the floor, inside
    }
}

module lid() {
    difference() {
        rbox([HX, HY, LID_T], r = 1.6);
        for (x = [WALL + 5, HX - WALL - 5], y = [WALL + 5, HY - WALL - 5])
            translate([x, y, -1]) cylinder(d = 3.2, h = LID_T + 2);
    }
}

// Drum, modelled along +x from x = 0 (= DRUM_X0 in the housing).
module drum() {
    difference() {
        union() {
            rotate([0, 90, 0]) cylinder(r = FLANGE_R, h = 3);
            rotate([0, 90, 0]) cylinder(r = CORE_R, h = DRUM_X1 - DRUM_X0);
            translate([DRUM_X1 - DRUM_X0 - 3, 0, 0]) rotate([0, 90, 0]) cylinder(r = FLANGE_R, h = 3);
            rotate([0, 90, 0]) cylinder(r = 8, h = HUB_X1 - DRUM_X0);   // hub tube
        }
        // axle bore: undersized, drill to 1/4" and glue (CA or epoxy)
        translate([-1, 0, 0]) rotate([0, 90, 0]) cylinder(d = AXLE_D - 0.2, h = 200);
        // cord anchor: chord hole that misses the axle bore
        translate([(DRUM_X1 - DRUM_X0) / 2, -CORE_R - 1, 7.5]) rotate([-90, 0, 0])
            cylinder(d = 2.5, h = 2 * CORE_R + 2);
    }
}

CRANK_R = 45;     // handle radius
module crank() {
    difference() {
        union() {
            cylinder(r = 10, h = 10);                                     // hub
            hull() {
                cylinder(r = 7, h = 6);
                translate([CRANK_R, 0, 0]) cylinder(r = 7, h = 6);
            }
            // knob: 1" tall, 7/8" across - fixed to the arm (no pinch gap)
            translate([CRANK_R, 0, 0]) cylinder(r = 11, h = 6 + 25.4);
            translate([CRANK_R, 0, 6 + 25.4]) scale([1, 1, 0.5]) sphere(r = 11);
        }
        translate([0, 0, -1]) cylinder(d = AXLE_D - 0.2, h = 12);   // drill to 1/4", glue
    }
}

module assembly() {
    color("SteelBlue", 0.6) housing();
    color("SteelBlue", 0.35) translate([0, 0, HZ - LID_T]) lid();
    color("Orange") translate([DRUM_X0, AXLE_Y, AXLE_Z]) drum();
    color("Silver") translate([2, AXLE_Y, AXLE_Z]) rotate([0, 90, 0]) cylinder(d = AXLE_D, h = 4.25 * IN);
    color("Black") translate([HX + 4, AXLE_Y, AXLE_Z]) rotate([0, 90, 0]) cylinder(r = 6.5, h = 2.6);  // O-ring
    color("Orange") translate([HX + 6.6, AXLE_Y, AXLE_Z]) rotate([0, 90, 0]) crank();
}

// ---- print layouts (each part flat-side down)
if (part == "housing") housing();
else if (part == "lid") lid();
else if (part == "drum") rotate([0, -90, 0]) drum();          // stand on its first flange
else if (part == "crank") crank();
else assembly();
