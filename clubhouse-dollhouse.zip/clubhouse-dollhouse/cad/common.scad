// common.scad - shared parameters and helpers for the printed parts
// Units: millimetres (the plywood house is designed in inches; IN converts).
// Every printed part is sized so it can NOT pass the 1.25" small-parts
// cylinder: its two smallest overall dimensions are both > 31.75 mm.

IN      = 25.4;
WALL    = 3.0;      // printed wall thickness (3+ perimeters at 0.4 nozzle)
FILLET  = 1.6;      // outside corner radius - no sharp corners on toys
CLEAR   = 0.3;      // general sliding clearance for FDM parts
$fn     = 48;

// --- house numbers the printed parts must agree with (see tools/house_model.py)
PLY_T     = 0.472 * IN;   // measured plywood thickness
SHAFT     = 3.25  * IN;   // elevator shaft clear width & depth
CAR       = 3.0   * IN;   // car outer width & depth
CAR_H     = 4.0   * IN;   // car outer height
GROOVE_W  = 0.25  * IN;   // guide groove in shaft walls
GROOVE_D  = 0.1875* IN;

// Box with every edge rounded (radius r), corner at origin.
module rbox(size, r = FILLET) {
    rr = min(r, min(size) / 2 - 0.01);
    hull()
        for (x = [rr, size[0] - rr], y = [rr, size[1] - rr], z = [rr, size[2] - rr])
            translate([x, y, z]) sphere(r = rr, $fn = 20);
}

// Same, but with a flat bottom (cleaner first layer on the bed).
module rbox_flat(size, r = FILLET) {
    rr = min(r, min(size) / 2 - 0.01);
    hull()
        for (x = [rr, size[0] - rr], y = [rr, size[1] - rr]) {
            translate([x, y, 0]) cylinder(r = rr, h = size[2] - rr, $fn = 20);
            translate([x, y, size[2] - rr]) sphere(r = rr, $fn = 20);
        }
}

// Countersunk hole for a #6 wood screw, pointing down from z = top.
module cs_hole_6(top, depth = 20) {
    translate([0, 0, top - depth]) cylinder(d = 3.8, h = depth + 0.01);
    translate([0, 0, top - 2.6]) cylinder(d1 = 3.8, d2 = 8.6, h = 2.61);
}
