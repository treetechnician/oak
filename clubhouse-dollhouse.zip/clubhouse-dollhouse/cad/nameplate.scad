// nameplate.scad - sign for above the front door.
// Set `label` locally before you export.  Tip: the repo is public, so keep
// your kid's name out of the committed file and just edit it on your machine.
//
// PRINT: flat, text up.  For two colours without a multi-colour printer,
//        add a filament change (M600 / "pause at height") at the layer where
//        the letters start (PLATE_T = 4 mm -> first layer above 4.0 mm).
// MOUNT: wood glue or two #6 x 5/8" pan-head screws through the holes.

include <common.scad>

label     = "CLUBHOUSE";
font      = "Liberation Sans:style=Bold";
PLATE_L   = 6.0 * IN;      // 152 mm - fits a 220 mm bed with room to spare
PLATE_H   = 1.5 * IN;      //  38 mm
PLATE_T   = 4;
TEXT_H    = 1.6;           // raised letter height
TEXT_SIZE = 15;            // shrink for long names; letters should stay >= 10
SCREWS    = true;

difference() {
    rbox_flat([PLATE_L, PLATE_H, PLATE_T], r = 2);
    if (SCREWS)
        for (x = [8, PLATE_L - 8])
            translate([x, PLATE_H / 2, 0]) cs_hole_6(PLATE_T, PLATE_T + 1);
}
translate([PLATE_L / 2, PLATE_H / 2, PLATE_T - 0.01])
    linear_extrude(TEXT_H)
        resize([min(PLATE_L - 34, len(label) * TEXT_SIZE * 0.78), 0], auto = true)
            text(label, size = TEXT_SIZE, font = font, halign = "center", valign = "center");
