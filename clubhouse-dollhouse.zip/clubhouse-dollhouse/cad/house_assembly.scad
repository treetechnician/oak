// house_assembly.scad - the plywood house as a visual check model (do NOT print).
// Units: INCHES, matching tools/house_model.py (the source of truth for the
// cut list).  Change T to your measured plywood and compare against the script.
//
// show_phase2 toggles the elevator shaft, car and winch housing.
// explode > 0 pulls the parts apart for an assembly-order picture.

T        = 0.472;
W        = 24;   D = 10;   ROOM_H = 9;   DADO = 0.25;
RISE     = 8;    FRONT_OH = 1;
SHAFT    = 3.25; CAR = 3.0; CAR_H = 4.0;
BASE_X0  = -0.75; BASE_X1 = 28.5; BASE_Y0 = -1.5; BASE_Y1 = 12;
CLEAT_W  = 1;
show_phase2 = true;
explode  = 0;          // try 3

SLOPE   = RISE / (W / 2);
THETA   = atan(SLOPE);
Z_MID   = ROOM_H;
Z_SIDE  = 2 * ROOM_H + T;
Z_ATTIC = Z_SIDE + T;
Z_RIDGE = Z_ATTIC + RISE;
X_DIV   = W / 2 - T / 2;
SH_Y0   = D - SHAFT;
SH_X1   = W + SHAFT;
TZ      = T / cos(THETA);
E       = explode;

// 2-D polygon in (a,b), extruded thickness t
module xz(y0, t) multmatrix([[1,0,0,0],[0,0,1,y0],[0,1,0,0]]) linear_extrude(t) children();   // (x,z) along y
module yz(x0, t) multmatrix([[0,0,1,x0],[1,0,0,0],[0,1,0,0]]) linear_extrude(t) children();   // (y,z) along x
module xy(z0, t) translate([0,0,z0]) linear_extrude(t) children();                            // (x,y) along z

module box2(a0, b0, a1, b1) translate([a0, b0]) square([a1 - a0, b1 - b0]);

WOOD = [0.87, 0.74, 0.55]; DARK = [0.78, 0.62, 0.43]; ROOFC = [0.55, 0.42, 0.36];
PINE = [0.93, 0.83, 0.62]; PLA = [0.25, 0.55, 0.72];

// base
color(DARK) translate([0, 0, -E]) xy(-T, T) box2(BASE_X0, BASE_Y0, BASE_X1, BASE_Y1);

// side walls (left has two windows)
color(WOOD) translate([-E, 0, 0]) yz(0, T) difference() {
    box2(T, 0, D, Z_SIDE);
    box2(3.5, 2.5, 7.5, 6.5);
    box2(3.5, Z_MID + T + 2.5, 7.5, Z_MID + T + 6.5);
}
color(WOOD) translate([E, 0, 0]) yz(W - T, T) box2(T, 0, D, Z_SIDE);

// floors
color(WOOD) xy(Z_MID, T) box2(T - DADO, T, W - T + DADO, D);
color(WOOD) translate([0, 0, E]) xy(Z_SIDE, T) box2(0, T, W, D);

// dividers with doorways
module divider(z0) difference() {
    box2(T, z0, D, z0 + ROOM_H);
    polygon([[3.5, z0], [7.5, z0], [7.5, z0 + 5.6], [7.1, z0 + 6], [3.9, z0 + 6], [3.5, z0 + 5.6]]);
}
color(WOOD) yz(X_DIV, T) divider(0);
color(WOOD) translate([0, 0, E / 2]) yz(X_DIV, T) divider(Z_MID + T);

// front facade
XL = (T + X_DIV) / 2;  XR = (X_DIV + W) / 2;
color(WOOD) translate([0, -E, 0]) xz(0, T) difference() {
    polygon([[0, 0], [W, 0], [W, Z_ATTIC], [W / 2, Z_RIDGE], [0, Z_ATTIC]]);
    polygon([[3.868, -0.1], [8.368, -0.1], [8.368, 6], [7.868, 6.5], [4.368, 6.5], [3.868, 6]]);
    box2(XR - 2, 3, XR + 2, 7);
    box2(XL - 2, Z_MID + T + 2.5, XL + 2, Z_MID + T + 6.5);
    box2(XR - 2, Z_MID + T + 2.5, XR + 2, Z_MID + T + 6.5);
    translate([W / 2, Z_ATTIC + 3.2]) circle(r = 1.75, $fn = 64);
}

// rear gable frame
OFF = 1.5; DZ = OFF / cos(THETA); XI = (OFF + DZ) / SLOPE;
ZC = Z_ATTIC + CLEAT_W * SLOPE;
color(WOOD) translate([0, E, E]) xz(D - T, T) difference() {
    polygon([[CLEAT_W, Z_ATTIC], [W - CLEAT_W, Z_ATTIC], [W - CLEAT_W, ZC], [W / 2, Z_RIDGE], [CLEAT_W, ZC]]);
    polygon([[XI, Z_ATTIC + OFF], [W - XI, Z_ATTIC + OFF], [W / 2, Z_RIDGE - DZ]]);
}

// eave cleats
color(PINE) translate([0, 0, E]) xz(T, D - T) polygon([[0, Z_ATTIC], [CLEAT_W, Z_ATTIC], [CLEAT_W, ZC]]);
color(PINE) translate([0, 0, E]) xz(T, D - T) polygon([[W, Z_ATTIC], [W - CLEAT_W, Z_ATTIC], [W - CLEAT_W, ZC]]);

// roof panels, plumb-cut at eave and ridge
color(ROOFC) translate([-E / 2, 0, 2 * E]) xz(-FRONT_OH, D + FRONT_OH)
    polygon([[0, Z_ATTIC], [W / 2, Z_RIDGE], [W / 2, Z_RIDGE + TZ], [0, Z_ATTIC + TZ]]);
color(ROOFC) translate([E / 2, 0, 2 * E]) xz(-FRONT_OH, D + FRONT_OH)
    polygon([[W, Z_ATTIC], [W / 2, Z_RIDGE], [W / 2, Z_RIDGE + TZ], [W, Z_ATTIC + TZ]]);

// phase 2: elevator
if (show_phase2) {
    color(WOOD) translate([E, 0, 0]) xz(SH_Y0 - T, T) box2(W, 0, SH_X1 + T, Z_ATTIC);
    color(WOOD) translate([2 * E, 0, 0]) yz(SH_X1, T) box2(SH_Y0, 0, D, Z_ATTIC);
    CX0 = W + (SHAFT - CAR) / 2; CY0 = D - CAR - 0.125;
    color(PLA) translate([CX0 + E, CY0, 0]) cube([CAR, CAR, CAR_H]);
    color(PLA) translate([W + E, SH_Y0 - T, Z_ATTIC + E]) cube([SHAFT + T, SHAFT + T, 2.5]);
}
